package hellotvxlet;

import org.havi.ui.HVisible;

/**
 *
 * @author student
 */
public class ScoreController {

	private int mScore = 0;
	private int mPointsLine = 5;
	private int mTotalLines = 0;	
	private int mNextLevelScore = 10;
        private GameView single;

	//private static ScoreController instance = new ScoreController();
	
	public ScoreController(GameView single) {
		this.single=single;
	}
	
/*	public static ScoreController getInstance() {
		return instance;
	}*/
	
	public void UpdatePointsLine() {
		mPointsLine *= 2;
	}

	public void AddScore(byte linesGotten) {
		mScore += mPointsLine * Math.pow(linesGotten, 1.5);
		mTotalLines += linesGotten;
		single.GetScoreLabel().setTextContent("Score: "+mScore, HVisible.ALL_STATES);
		single.GetAmountOfLinesLabel().setTextContent("Amount of lines: "+mTotalLines, HVisible.ALL_STATES);
		if (mScore >= mNextLevelScore) {
                        single.getLevelController().LevelUp();
			mNextLevelScore += mNextLevelScore *1.2;
		}
	}

	public int GetScore() {
		return mScore;
	}

	public int GetTotalLines() {
		return mTotalLines;
	}
}
