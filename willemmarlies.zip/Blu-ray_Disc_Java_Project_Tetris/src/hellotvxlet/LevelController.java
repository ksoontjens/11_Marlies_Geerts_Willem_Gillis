package hellotvxlet;

import org.havi.ui.HVisible;

/**
 *
 * @author student
 */
public class LevelController {

	private int mSpeedMultiplier = 1000;
	private byte mLevelAmount = 1;
        private GameView single;

	//private static LevelController instance = new LevelController();
	
	public LevelController(GameView single) {
		this.single=single;
	}
	
	/*public static LevelController getInstance() {
		return instance;
	}*/
		
	public void LevelUp() {
		mLevelAmount++;
		mSpeedMultiplier *= 0.9f;
		single.GetLevelLabel().setTextContent("Level: "+mLevelAmount, HVisible.ALL_STATES);
	}

	public int GetSpeed() {
		return mSpeedMultiplier;
	}
	
	public byte GetLevelAmount() {
		return mLevelAmount;
	}
}
